#!/usr/bin/python
#Filename:mymodule.py

def sayhi():
    print('Hi, this is mymodule test')
version = '0.1'

# end of mymodule